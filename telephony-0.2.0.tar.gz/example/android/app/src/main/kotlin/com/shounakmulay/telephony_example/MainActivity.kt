package com.shounakmulay.telephony_example

import android.content.IntentFilter
import android.os.Bundle
import android.os.PersistableBundle
import com.shounakmulay.telephony.sms.IncomingSmsReceiver
import io.flutter.app.FlutterApplication
import io.flutter.embedding.android.FlutterActivity

class MainActivity :FlutterActivity() {}

class MyApp: FlutterApplication() {
  
}
