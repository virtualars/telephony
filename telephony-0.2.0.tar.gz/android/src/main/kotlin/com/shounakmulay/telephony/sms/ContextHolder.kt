package com.shounakmulay.telephony.sms

import android.content.Context
import com.shounakmulay.telephony.sms.ContextHolder

object ContextHolder {
    var applicationContext: Context? = null
}